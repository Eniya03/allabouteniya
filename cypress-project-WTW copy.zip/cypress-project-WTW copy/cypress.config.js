const { defineConfig } = require("cypress");

module.exports = defineConfig({
  e2e: {
     // Base URL for all test
     //baseUrl: 'http://localhost:3000/',
    viewportWidth: 1280, // Standard desktop viewport width
    viewportHeight: 720, // Standard desktop viewport height
    retries: {
      runMode: 0, // Retries for test runs in headless mode
      openMode: 0  // Retries for tests in interactive mode
    },
    defaultCommandTimeout: 8000, // Timeout for commands (ms)
    pageLoadTimeout: 90000, // Timeout for page load (ms)
    screenshotOnRunFailure: true, // Capture screenshots on test failures
    video: false, // Disable video recording for local runs
    supportFile: "cypress/support/index.js", // Path to support file
    specPattern: "cypress/Tests/E2ETest.cy.js", // Path to test spec files
    env: {
     headlessMode: process.env.HEADLESS_MODE || "true", // Default to true
    },
    setupNodeEvents(on, config) {
      //for plugins in future
    },
  },
});

//const allureWriter = require('@shelex/cypress-allure-plugin/writer');
 
/*module.exports = defineConfig({
 
  reporter: 'cypress-mochawesome-reporter',
  env: {
    headlessMode: process.env.HEADLESS_MODE || "true",
  },
 
  video: true,
  pageLoadTimeout: 30000,
  taskTimeout: 30000,
  requestTimeout: 30000,
  responseTimeout: 20000,
  defaultCommandTimeout: 5000,
  watchForFileChanges: false,
  screenshotOnRunFailure: true,
  screenshotsFolder: 'cypress/screenshots',
  trashAssetsBeforeRuns: true,
  capture: 'fullPage',
  retries: {
    openMode: 0 // for 2 attempts
  },
  viewportWidth: 1920,
  viewportHeight: 1080,
  chromeWebSecurity: false,
  numTestsKeptInMemory: 0,
 
  e2e: {
     
    testIsolation: false,
    setupNodeEvents(on, config) {
      on('after:screenshot', (details) => {
        /* ... */
     // })
      // implement node event listeners here
 
   // },
   
        //baseUrl:   'https://ri-software.com.ua/',
        //baseUrl: 'http://localhost:3000/',
        //video: true,
   
   //setupNodeEvents(on, config) //{
 
   
    // require('cypress-mochawesome-reporter/plugin')(on);
 
     //allureWriter(on, config);
    // return config;
 
  // },
 
 //},
 
//});*/
