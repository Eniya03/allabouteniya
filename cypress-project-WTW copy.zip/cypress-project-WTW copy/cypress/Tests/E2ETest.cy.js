/// <reference types="cypress" />
const testData = require('../fixtures/TestData.json');
import {changeLanguage} from '../support/commands.js';
describe('WTW Website Tests', () => {

  it('Validates IFRS 17 Search Functionality for US English', () => {
    // Arrange
    
    cy.visit('Testdata.data')

    cy.get('#onetrust-reject-all-handler').click()
   
    // Change language to the default (US English)

    const language = testData.languages[testData.defaultLanguage];
    cy.changeLanguage(language);

    // Act
    cy.performSearch(testData.searchQuery);

    // Assert: Validate arrival on result page
    cy.url().should('include', 'search-results');

    // Validate and sort by "Date"
    cy.setSortOption(testData.sortOptions.date);
    cy.get('select[data-test-id="sort-by"]')
      .should('have.value', testData.sortOptions.date);

    // Test sorting by "Relevance"
    cy.setSortOption(testData.sortOptions.relevance);
    cy.get('select[data-test-id="sort-by"]')
      .should('have.value', testData.sortOptions.relevance);

    // Revert to "Date" sorting
    cy.setSortOption(testData.sortOptions.date);

    // Filter by "Article"
    cy.filterByContentType('Article');

    // Validate links start with the expected base URL
    cy.validateLinks(testData.expectedLinkStart);
  });

  });