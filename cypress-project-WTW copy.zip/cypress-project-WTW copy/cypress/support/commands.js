

Cypress.Commands.add('changeLanguage', (language) => {
    // Open the language/region selector menu
   // cy.get('.global-header__nav-item--language > button').click();
   cy.get('#region-0 > .material-symbols-outlined').click()
   cy.get('.country-selector__container').scrollTo('bottom')
  });
  
  Cypress.Commands.add('performSearch', (query) => {
    // Locate and use the search box
    cy.get('#region0 > .row > .col > tbody > :nth-child(15) > :nth-child(2) > .text-left > .d-inline-block').click() // Open search
    cy.get('.site-nav__btn--search-menu').click()
    cy.get('form > input').type(query).type('{enter}')
      
  });
  
  Cypress.Commands.add('setSortOption', (option) => {
    // Set the sort option dynamically (e.g., date or relevance)
    cy.get('select[data-test-id="sort-by"]').then(($dropdown) => {
      const selected = $dropdown.val();
      if (selected !== option) {
        cy.get('select[data-test-id="sort-by"]').select(option);
      }
    });
  });
  
  Cypress.Commands.add('filterByContentType', (contentType) => {
    cy.get('[data-value="Article"] > .coveo-facet-value-label > .coveo-facet-value-label-wrapper > .coveo-facet-value-checkbox').click()
  });
  
  Cypress.Commands.add('validateLinks', (expectedStart) => {
    cy.xpath("//div[@class='coveo-list-layout CoveoResult']/a/div/div[@class='coveo-result-row']//div[@class='CoveoFieldValue wtw-listing-result-uri']")
    .each(($row) => {
         cy.wrap($row).find("span")
        .should('contains.text','https://www.wtwco.com/en-us')
        
        
    })
    });
  
  